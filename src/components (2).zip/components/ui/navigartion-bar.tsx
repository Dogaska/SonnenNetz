import { Fragment } from "react";
import {
  Disclosure,
  DisclosureButton,
  DisclosurePanel,
  Menu,
  MenuButton,
  MenuItem,
  MenuItems,
  Transition,
} from "@headlessui/react";
import { Bars3Icon, BellIcon, XMarkIcon } from "@heroicons/react/24/outline";

const navigation = [
  { name: "Home", href: "home", current: true },
  { name: "Projects", href: "projects", current: false },
  { name: "Services", href: "services", current: false },
  { name: "Resources", href: "resources", current: false },
  { name: "About Us", href: "about", current: false },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export function NavigationBar() {
  return (
    <>
      {/*
       
      */}
      <div className="min-h-full">
        <Disclosure as="nav" className="bg-gray-800">
          {({ open }) => (
            <>
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex h-16 items-center justify-between">
                  {" "}
                  {/* Ensures space between items */}
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <img
                        className="h-12 w-auto"
                        src="src/assets/images/Logo_sonnennetz.svg"
                        alt="Your Company"
                      />
                    </div>
                  </div>
                  {/* This 'div' now uses 'ml-auto' to push navigation to the right */}
                  <div className="hidden md:flex ml-auto">
                    <div className="ml-10 flex items-baseline space-x-4">
                      {navigation.map((item) => (
                        <a
                          key={item.name}
                          href={item.href}
                          className={classNames(
                            item.current
                              ? "bg-gray-900 text-white"
                              : "text-gray-300 hover:bg-gray-700 hover:text-white",
                            "rounded-md px-3 py-2 text-sm font-medium"
                          )}
                          aria-current={item.current ? "page" : undefined}
                        >
                          {item.name}
                        </a>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              {/* Mobile Menu and the rest of your component remains unchanged */}
            </>
          )}
        </Disclosure>
      </div>
    </>
  );
}
